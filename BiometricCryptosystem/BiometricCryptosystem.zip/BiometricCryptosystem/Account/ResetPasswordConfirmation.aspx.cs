﻿using System.Web.UI;

namespace BiometricCryptosystem.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}